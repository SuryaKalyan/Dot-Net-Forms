﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerData
{
    public interface ICustomer
    {
        bool AddCustomer(Data c);
        bool RemoveCustomer(Data c);
    }
}
