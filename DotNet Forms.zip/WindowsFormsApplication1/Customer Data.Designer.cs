﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtId = new System.Windows.Forms.Label();
            this.id = new System.Windows.Forms.TextBox();
            this.txtFName = new System.Windows.Forms.Label();
            this.FName = new System.Windows.Forms.TextBox();
            this.txtLName = new System.Windows.Forms.Label();
            this.LName = new System.Windows.Forms.TextBox();
            this.txtAge = new System.Windows.Forms.Label();
            this.age = new System.Windows.Forms.TextBox();
            this.txtMail = new System.Windows.Forms.Label();
            this.email = new System.Windows.Forms.TextBox();
            this.txtPhNo = new System.Windows.Forms.Label();
            this.PhNo = new System.Windows.Forms.TextBox();
            this.txtAdd = new System.Windows.Forms.Label();
            this.Address = new System.Windows.Forms.RichTextBox();
            this.Submit = new System.Windows.Forms.Button();
            this.Cancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtId
            // 
            this.txtId.AutoSize = true;
            this.txtId.Location = new System.Drawing.Point(35, 45);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(18, 13);
            this.txtId.TabIndex = 0;
            this.txtId.Text = "ID";
            // 
            // id
            // 
            this.id.Location = new System.Drawing.Point(124, 38);
            this.id.Name = "id";
            this.id.Size = new System.Drawing.Size(38, 20);
            this.id.TabIndex = 1;
            // 
            // txtFName
            // 
            this.txtFName.AutoSize = true;
            this.txtFName.Location = new System.Drawing.Point(35, 82);
            this.txtFName.Name = "txtFName";
            this.txtFName.Size = new System.Drawing.Size(57, 13);
            this.txtFName.TabIndex = 2;
            this.txtFName.Text = "First Name";
            this.txtFName.Click += new System.EventHandler(this.txtFName_Click);
            // 
            // FName
            // 
            this.FName.Location = new System.Drawing.Point(124, 75);
            this.FName.Name = "FName";
            this.FName.Size = new System.Drawing.Size(144, 20);
            this.FName.TabIndex = 3;
            // 
            // txtLName
            // 
            this.txtLName.AutoSize = true;
            this.txtLName.Location = new System.Drawing.Point(34, 123);
            this.txtLName.Name = "txtLName";
            this.txtLName.Size = new System.Drawing.Size(58, 13);
            this.txtLName.TabIndex = 4;
            this.txtLName.Text = "Last Name";
            // 
            // LName
            // 
            this.LName.Location = new System.Drawing.Point(124, 120);
            this.LName.Name = "LName";
            this.LName.Size = new System.Drawing.Size(144, 20);
            this.LName.TabIndex = 5;
            this.LName.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtAge
            // 
            this.txtAge.AutoSize = true;
            this.txtAge.Location = new System.Drawing.Point(35, 166);
            this.txtAge.Name = "txtAge";
            this.txtAge.Size = new System.Drawing.Size(26, 13);
            this.txtAge.TabIndex = 6;
            this.txtAge.Text = "Age";
            // 
            // age
            // 
            this.age.Location = new System.Drawing.Point(124, 163);
            this.age.Name = "age";
            this.age.Size = new System.Drawing.Size(38, 20);
            this.age.TabIndex = 7;
            // 
            // txtMail
            // 
            this.txtMail.AutoSize = true;
            this.txtMail.Location = new System.Drawing.Point(35, 208);
            this.txtMail.Name = "txtMail";
            this.txtMail.Size = new System.Drawing.Size(36, 13);
            this.txtMail.TabIndex = 8;
            this.txtMail.Text = "E Mail";
            // 
            // email
            // 
            this.email.Location = new System.Drawing.Point(124, 201);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(143, 20);
            this.email.TabIndex = 9;
            // 
            // txtPhNo
            // 
            this.txtPhNo.AutoSize = true;
            this.txtPhNo.Location = new System.Drawing.Point(35, 248);
            this.txtPhNo.Name = "txtPhNo";
            this.txtPhNo.Size = new System.Drawing.Size(55, 13);
            this.txtPhNo.TabIndex = 10;
            this.txtPhNo.Text = "Phone No";
            // 
            // PhNo
            // 
            this.PhNo.Location = new System.Drawing.Point(124, 248);
            this.PhNo.Name = "PhNo";
            this.PhNo.Size = new System.Drawing.Size(144, 20);
            this.PhNo.TabIndex = 11;
            this.PhNo.TextChanged += new System.EventHandler(this.PhNo_TextChanged);
            // 
            // txtAdd
            // 
            this.txtAdd.AutoSize = true;
            this.txtAdd.Location = new System.Drawing.Point(35, 296);
            this.txtAdd.Name = "txtAdd";
            this.txtAdd.Size = new System.Drawing.Size(45, 13);
            this.txtAdd.TabIndex = 12;
            this.txtAdd.Text = "Address";
            // 
            // Address
            // 
            this.Address.Location = new System.Drawing.Point(129, 293);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(138, 59);
            this.Address.TabIndex = 13;
            this.Address.Text = "";
            // 
            // Submit
            // 
            this.Submit.Location = new System.Drawing.Point(51, 398);
            this.Submit.Name = "Submit";
            this.Submit.Size = new System.Drawing.Size(135, 23);
            this.Submit.TabIndex = 14;
            this.Submit.Text = "Submit";
            this.Submit.UseVisualStyleBackColor = true;
            this.Submit.Click += new System.EventHandler(this.Submit_Click);
            // 
            // Cancel
            // 
            this.Cancel.Location = new System.Drawing.Point(254, 398);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(134, 22);
            this.Cancel.TabIndex = 15;
            this.Cancel.Text = "Cancel";
            this.Cancel.UseVisualStyleBackColor = true;
            this.Cancel.Click += new System.EventHandler(this.Cancel_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(811, 451);
            this.Controls.Add(this.Cancel);
            this.Controls.Add(this.Submit);
            this.Controls.Add(this.Address);
            this.Controls.Add(this.txtAdd);
            this.Controls.Add(this.PhNo);
            this.Controls.Add(this.txtPhNo);
            this.Controls.Add(this.email);
            this.Controls.Add(this.txtMail);
            this.Controls.Add(this.age);
            this.Controls.Add(this.txtAge);
            this.Controls.Add(this.LName);
            this.Controls.Add(this.txtLName);
            this.Controls.Add(this.FName);
            this.Controls.Add(this.txtFName);
            this.Controls.Add(this.id);
            this.Controls.Add(this.txtId);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label txtId;
        private System.Windows.Forms.TextBox id;
        private System.Windows.Forms.Label txtFName;
        private System.Windows.Forms.TextBox FName;
        private System.Windows.Forms.Label txtLName;
        private System.Windows.Forms.TextBox LName;
        private System.Windows.Forms.Label txtAge;
        private System.Windows.Forms.TextBox age;
        private System.Windows.Forms.Label txtMail;
        private System.Windows.Forms.TextBox email;
        private System.Windows.Forms.Label txtPhNo;
        private System.Windows.Forms.TextBox PhNo;
        private System.Windows.Forms.Label txtAdd;
        private System.Windows.Forms.RichTextBox Address;
        private System.Windows.Forms.Button Submit;
        private System.Windows.Forms.Button Cancel;
    }
}

