﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CustomerData;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtFName_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Submit_Click(object sender, EventArgs e)
        {
            CustomerData.Data c = new Data();
            c.Id = Int32.Parse(id.Text);
            c.FirstName = FName.Text.ToString();
            c.LastName = LName.Text.ToString();
            c.Age = Int32.Parse(age.Text); 
            c.email = email.Text.ToString();
            c.PhNo = PhNo.Text.ToString();
            c.address = Address.Text.ToString();
            ICustomer operate = new CustomerData.CustomerOperations();
            operate.AddCustomer(c);
           

        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void PhNo_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
