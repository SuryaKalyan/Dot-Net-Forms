﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FileHandling;

namespace CustomerData
{
  public  class CustomerOperations:ICustomer
    {
        bool ICustomer.AddCustomer(Data c)
        {
            IHandling fh = new FHandle(); 
            fh.AddtoFile(c.Id, c.FirstName, c.LastName,c.Age, c.email,c.PhNo, c.address);
            return true;
        }

        bool ICustomer.RemoveCustomer(Data c)
        {
            throw new NotImplementedException();
        }
    }
}
