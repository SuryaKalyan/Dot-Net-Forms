﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace FileHandling
{
    public class FHandle:IHandling
    {
        bool IHandling.AddtoFile(int id, string fname, string lname, int age, string mail, string phno, string address)
        {
            FileStream fs = new FileStream(@"K:\Test\customer.txt", FileMode.Append, FileAccess.Write, FileShare.Read);
            StreamWriter sw = new StreamWriter(fs);
            sw.Write(id);
            sw.Write(fname);
            sw.Write(lname);
            sw.Write(age);
            sw.Write(mail);
            sw.Write(phno);
            sw.WriteLine(address);
            sw.Close();
            return true;
        }
    }
}
