﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileHandling
{
    public interface IHandling
    {
        bool AddtoFile(int Id, string FirstName, string LastName, int Age, string email, string PhNo, string address);
    }
}
